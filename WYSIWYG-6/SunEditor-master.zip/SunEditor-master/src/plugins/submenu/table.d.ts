import { SubmenuPlugin } from '../SubmenuPlugin';

declare const table: SubmenuPlugin;

export default table;