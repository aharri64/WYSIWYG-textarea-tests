import { SubmenuPlugin } from '../SubmenuPlugin';

declare const fontColor: SubmenuPlugin;

export default fontColor;