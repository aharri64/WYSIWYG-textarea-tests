import { SubmenuPlugin } from '../SubmenuPlugin';

declare const fontSize: SubmenuPlugin;

export default fontSize;