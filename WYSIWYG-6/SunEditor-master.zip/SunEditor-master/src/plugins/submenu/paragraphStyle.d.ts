import { SubmenuPlugin } from '../SubmenuPlugin';

declare const paragraphStyle: SubmenuPlugin;

export default paragraphStyle;