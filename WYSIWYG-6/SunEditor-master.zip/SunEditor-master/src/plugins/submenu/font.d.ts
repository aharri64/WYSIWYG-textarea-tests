import { SubmenuPlugin } from '../SubmenuPlugin';

declare const font: SubmenuPlugin;

export default font;