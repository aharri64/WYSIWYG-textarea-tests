import { Lang } from './Lang';

declare const ptBr: Lang;

export default ptBr;