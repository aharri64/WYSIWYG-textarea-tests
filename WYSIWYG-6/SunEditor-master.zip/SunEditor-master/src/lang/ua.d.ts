import { Lang } from "./Lang";

declare const ua: Lang;

export default ua;
