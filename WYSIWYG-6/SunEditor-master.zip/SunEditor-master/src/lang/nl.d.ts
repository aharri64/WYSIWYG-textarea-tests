import { Lang } from './Lang';

declare const nl: Lang;

export default nl;